const path = require("path");
const express = require("express");
const bodyParser = require("body-parser");
const mongoose = require("mongoose");
const cors = require('cors');

const postsRoutes = require("./routes/posts");
const userRoutes = require("./routes/user");

const app = express();

//connect to mongodb with mongoose
mongoose
  .connect(
    "mongodb+srv://Hani:" +
    process.env.MONGO_ATLAS_PW +
    "@cluster0.vqyni.mongodb.net/node-angular"
  )
  .then(() => {
    console.log("Connected to database!");
  })
  .catch(() => {
    console.log("Connection failed!");
  });

  app.use(function(req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, PATCH, DELETE');
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept,Authorization");
    next();
  });

  app.use(bodyParser.json());
  app.use(bodyParser.urlencoded({ extended: false }));
  app.use("/images", express.static(path.join("images")));



  app.use("/api/posts", postsRoutes);
  app.use("/api/user", userRoutes);

  module.exports = app;
